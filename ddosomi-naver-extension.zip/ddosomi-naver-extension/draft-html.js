/* 또소미 네이버 자동 임시저장 — 에디터에 넣을 블록 만들기 (순수 함수 모음)

   원칙
   · HTML 태그 문자열(<div><b>…</b></div>)은 절대 텍스트로 넣지 않는다 → stripTags()로 먼저 지운다.
   · [확인 필요] · [직접 입력] · [미정] 같은 빈칸 표시도 지운다 → stripPlaceholders().
   · 글자 모양(서체·크기·정렬)은 content-naver.js가 에디터 툴바로 적용한다.
     여기서는 붙여넣기용 HTML(buildHtml)에만 스타일을 실어 둔다. */
(function (root) {
  'use strict';

  var FONT = "'NanumBarunGothic','나눔바른고딕','NanumGothic','나눔고딕','Malgun Gothic','Apple SD Gothic Neo',sans-serif";
  var HL = '#ffd300';
  var HEADER_BG = '#f5f6f8';
  var LINE = '#dfe5ec';

  var BODY_PT = 15;   /* 본문 15pt */
  var HEAD_PT = 15;   /* 표 헤더 15pt */
  var CELL_PT = 13;   /* 표 셀 13pt */
  var TITLE_PT = 16;  /* 표 제목 16pt */

  function T(s) { return String(s == null ? '' : s); }
  function trim(s) { return T(s).replace(/^\s+|\s+$/g, ''); }

  /* HTML 태그 문자열 제거 — 실제 태그, 이스케이프된 태그, 남은 꺾쇠까지 */
  function stripTags(s) {
    var t = T(s);
    t = t.replace(/<\/?[a-zA-Z][^>]*>/g, ' ');          /* <div align="center"> · </b> */
    t = t.replace(/&lt;\/?[a-zA-Z][^&]*?&gt;/g, ' ');   /* &lt;div&gt; */
    t = t.replace(/<\/?[a-zA-Z][^>]*$/g, ' ');          /* 잘린 태그 */
    t = t.replace(/[<>]/g, '');
    return t.replace(/[ \t]+/g, ' ').replace(/\s+$/g, '').replace(/^\s+/g, '');
  }

  /* 빈칸·플레이스홀더 제거 */
  var PLACEHOLDER = /\[\s*(확인\s*필요|직접\s*입력|미정|미확인|추후\s*입력|입력\s*필요|내용\s*입력|확인|TBD|TODO|N\/?A)\s*\]/gi;
  function stripPlaceholders(s) {
    var t = T(s).replace(PLACEHOLDER, ' ').replace(/\(\s*확인\s*필요\s*\)/g, ' ');
    return t.replace(/[ \t]{2,}/g, ' ');
  }

  /* 에디터에 들어갈 모든 글자는 이 함수를 거친다 */
  function clean(s) { return trim(stripPlaceholders(stripTags(s))); }

  function esc(s) {
    return T(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ==노란 형광펜== → 배경 #ffd300 + 볼드, **볼드** → 볼드 */
  function inline(s) {
    var out = esc(clean(s));
    out = out.replace(/==([^=]+?)==/g, '<span style="background-color:' + HL + ';font-weight:bold;">$1</span>');
    out = out.replace(/\*\*(.+?)\*\*/g, '<span style="font-weight:bold;">$1</span>');
    out = out.replace(/\n/g, '<br />');
    return out;
  }

  /* 본문 한 줄 */
  function paragraph(text) {
    return '<p style="text-align:center;font-family:' + FONT + ';font-size:' + BODY_PT + 'pt;line-height:1.8;margin:0 0 12px;">' +
      inline(text) + '</p>';
  }

  /* 소제목 — 에디터에서 '인용구' 블록으로 바꿀 자리(붙여넣기 사본에서는 인용구 모양) */
  function quote(text) {
    return '<p style="text-align:center;font-family:' + FONT + ';font-size:' + TITLE_PT + 'pt;font-weight:bold;line-height:1.5;' +
      'border-left:3px solid #c8d2de;background-color:#f7f9fb;padding:8px 12px;margin:22px 0 12px;">' +
      inline(text) + '</p>';
  }

  function imageHtml(dataUrl, alt) {
    return '<p style="text-align:center;margin:0 0 14px;"><img src="' + esc(dataUrl) + '" alt="' + esc(alt || '') +
      '" style="max-width:100%;height:auto;" /></p>';
  }

  /* 요약표 — 제목 16pt · 헤더 15pt(#f5f6f8) · 셀 13pt 가운데 정렬 */
  function table(t) {
    t = t || {};
    var header = t.header || [];
    var rows = t.rows || [];
    if (!header.length) { return ''; }
    var html = '';
    var title = clean(t.title);
    if (title) {
      html += '<p style="text-align:center;font-family:' + FONT + ';font-size:' + TITLE_PT + 'pt;font-weight:bold;line-height:1.4;margin:22px 0 9px;">' +
        esc(title) + '</p>';
    }
    html += '<table style="border-collapse:collapse;width:100%;font-family:' + FONT + ';"><tbody><tr>';
    for (var h = 0; h < header.length; h++) {
      html += '<td style="border:1px solid ' + LINE + ';background-color:' + HEADER_BG + ';font-size:' + HEAD_PT +
        'pt;font-weight:bold;text-align:center;vertical-align:middle;padding:8px 10px;">' + inline(header[h]) + '</td>';
    }
    html += '</tr>';
    for (var r = 0; r < rows.length; r++) {
      html += '<tr>';
      for (var c = 0; c < rows[r].length; c++) {
        html += '<td style="border:1px solid ' + LINE + ';font-size:' + CELL_PT +
          'pt;font-weight:normal;text-align:center;vertical-align:middle;padding:8px 10px;">' + inline(rows[r][c]) + '</td>';
      }
      html += '</tr>';
    }
    html += '</tbody></table>';
    return html;
  }

  function tags(list) {
    if (!list || !list.length) { return ''; }
    var cleanList = [];
    for (var i = 0; i < list.length; i++) {
      var w = clean(list[i]);
      if (w) { cleanList.push(w); }
    }
    if (!cleanList.length) { return ''; }
    return '<p style="text-align:center;font-family:' + FONT + ';font-size:' + CELL_PT + 'pt;margin:22px 0 0;">' +
      esc(cleanList.join(' ')) + '</p>';
  }

  function paragraphsOf(text) {
    var out = [];
    var lines = T(text).replace(/\r\n/g, '\n').split('\n');
    for (var i = 0; i < lines.length; i++) {
      var v = clean(lines[i]);
      if (v) { out.push(v); }
    }
    return out;
  }

  /* 에디터에 넣는 순서 그대로 블록을 만든다.
     { type:'paragraph' | 'quote' | 'image' | 'table' | 'tags' } */
  function buildBlocks(d) {
    d = d || {};
    var out = [];
    var intro = d.intro || [];
    var i;

    for (i = 0; i < intro.length; i++) {
      var it = clean(intro[i]);
      if (it) { out.push({ type: 'paragraph', text: it }); }
    }

    var sections = d.sections || [];
    for (i = 0; i < sections.length; i++) {
      var sec = sections[i] || {};
      var q = clean(sec.quote);
      if (q) { out.push({ type: 'quote', text: q }); }
      if (sec.photo) { out.push({ type: 'image', dataUrl: sec.photo, alt: q }); }
      var body = paragraphsOf(sec.body);
      for (var b = 0; b < body.length; b++) {
        out.push({ type: 'paragraph', text: body[b] });
      }
    }

    /* 본문 구조를 못 읽었을 때: 원문 문단을 그대로 넣는다 */
    if (!sections.length && T(d.bodyText)) {
      var raw = paragraphsOf(d.bodyText);
      for (i = 0; i < raw.length; i++) {
        out.push({ type: 'paragraph', text: raw[i] });
      }
    }

    if (d.table && d.table.header && d.table.header.length) {
      out.push({
        type: 'table',
        title: clean(d.table.title),
        header: d.table.header,
        rows: d.table.rows || []
      });
    }

    var closing = d.closing || [];
    for (i = 0; i < closing.length; i++) {
      var cl = clean(closing[i]);
      if (cl) { out.push({ type: 'paragraph', text: cl }); }
    }

    if (d.hashtags && d.hashtags.length) {
      var tg = tags(d.hashtags);
      if (tg) { out.push({ type: 'tags', list: d.hashtags }); }
    }

    return out;
  }

  /* 블록 하나 → 에디터에 넣을 HTML (글자는 이미 세척된 상태) */
  function blockHtml(b) {
    if (!b) { return ''; }
    if (b.type === 'paragraph') { return paragraph(b.text); }
    if (b.type === 'quote') { return quote(b.text); }
    if (b.type === 'table') { return table(b); }
    if (b.type === 'tags') { return tags(b.list); }
    if (b.type === 'image') { return imageHtml(b.dataUrl, b.alt); }
    return '';
  }

  function buildHtml(d) {
    var blocks = buildBlocks(d);
    var out = '';
    for (var i = 0; i < blocks.length; i++) { out += blockHtml(blocks[i]); }
    return out;
  }

  function cleanTextList(arr) {
    var out = [];
    arr = arr || [];
    for (var i = 0; i < arr.length; i++) { out.push(plainOf(arr[i])); }
    return out.join(' | ');
  }

  function plainOf(text) {
    return clean(text).replace(/==/g, '').replace(/\*\*/g, '');
  }

  function buildPlain(d) {
    d = d || {};
    var lines = [];
    if (clean(d.title)) { lines.push(clean(d.title)); }
    var intro = d.intro || [];
    for (var i = 0; i < intro.length; i++) {
      if (clean(intro[i])) { lines.push(plainOf(intro[i])); }
    }
    var sections = d.sections || [];
    for (var s = 0; s < sections.length; s++) {
      lines.push('');
      if (clean(sections[s].quote)) { lines.push(plainOf(sections[s].quote)); }
      var body = paragraphsOf(sections[s].body);
      for (var b = 0; b < body.length; b++) { lines.push(plainOf(body[b])); }
    }
    if (d.table && d.table.header && d.table.header.length) {
      lines.push('');
      if (clean(d.table.title)) { lines.push(clean(d.table.title)); }
      lines.push(cleanTextList(d.table.header));
      for (var r = 0; r < (d.table.rows || []).length; r++) { lines.push(cleanTextList(d.table.rows[r])); }
    }
    var closing = d.closing || [];
    for (var c = 0; c < closing.length; c++) {
      if (clean(closing[c])) { lines.push(plainOf(closing[c])); }
    }
    if (d.hashtags && d.hashtags.length) { lines.push(d.hashtags.join(' ')); }
    return lines.join('\n');
  }

  root.TtosomiDraft = {
    FONT: FONT,
    HIGHLIGHT: HL,
    SIZES: { body: BODY_PT, head: HEAD_PT, cell: CELL_PT, title: TITLE_PT },
    stripTags: stripTags,
    stripPlaceholders: stripPlaceholders,
    clean: clean,
    esc: esc,
    inline: inline,
    paragraph: paragraph,
    quote: quote,
    table: table,
    tags: tags,
    blockHtml: blockHtml,
    buildBlocks: buildBlocks,
    buildHtml: buildHtml,
    buildPlain: buildPlain
  };
})(typeof window !== 'undefined' ? window : this);
