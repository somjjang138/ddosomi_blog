/* 또소미 네이버 자동 임시저장 — 백그라운드(서비스 워커) */
'use strict';

var STORE_KEY = 'ddosomiDraft';

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) { return; }

  if (msg.type === 'DDOSOMI_SAVE_DRAFT') {
    var draft = msg.draft || {};
    if (!draft.blogId || !draft.title) {
      sendResponse({ ok: false, message: '초안에 블로그 ID나 제목이 없어요' });
      return true;
    }

    var record = {
      draftId: draft.draftId || '',
      blogId: draft.blogId,
      title: draft.title,
      receivedAt: Date.now(),
      draft: draft
    };

    chrome.storage.local.set({ ddosomiDraft: record }, function () {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, message: '초안 저장 실패: ' + chrome.runtime.lastError.message });
        return;
      }
      openEditor(draft.blogId, function (tab) {
        try {
          if (chrome.action && chrome.action.setBadgeText) {
            chrome.action.setBadgeText({ text: '1' });
            chrome.action.setBadgeBackgroundColor({ color: '#4b7cb3' });
          }
        } catch (e) {}
        sendResponse({ ok: true, tabId: tab && tab.id, message: 'ok' });
      });
    });
    return true;
  }

  if (msg.type === 'DDOSOMI_CONSUMED') {
    chrome.storage.local.remove(STORE_KEY);
    try {
      if (chrome.action && chrome.action.setBadgeText) { chrome.action.setBadgeText({ text: '' }); }
    } catch (e) {}
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'DDOSOMI_GET_LAST') {
    chrome.storage.local.get(STORE_KEY, function (data) {
      sendResponse({ ok: true, record: data && data[STORE_KEY] || null });
    });
    return true;
  }
});

/* 이미 열린 글쓰기 탭이 있으면 그 탭을 다시 쓰고, 없으면 새로 연다 */
function openEditor(blogId, cb) {
  var url = 'https://blog.naver.com/' + encodeURIComponent(blogId) + '/postwrite';

  chrome.tabs.query({}, function (tabs) {
    var found = null;
    for (var i = 0; i < (tabs || []).length; i++) {
      var t = tabs[i];
      if (t && t.url && /blog\.naver\.com\/.*postwrite/i.test(t.url)) { found = t; break; }
    }
    if (found) {
      chrome.tabs.update(found.id, { url: url, active: true }, function (tab) {
        if (chrome.runtime.lastError) { create(url, cb); return; }
        cb(tab);
      });
      return;
    }
    create(url, cb);
  });
}

function create(url, cb) {
  chrome.tabs.create({ url: url, active: true }, function (tab) {
    cb(tab);
  });
}

chrome.runtime.onInstalled.addListener(function () {
  try {
    chrome.action.setBadgeText({ text: '' });
  } catch (e) {}
});
