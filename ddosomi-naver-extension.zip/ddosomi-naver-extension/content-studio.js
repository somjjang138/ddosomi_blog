/* 또소미 스튜디오 페이지(somjjang138.github.io) ↔ 확장 프로그램 다리 */
(function () {
  'use strict';

  var PING = 'DDOSOMI_PING';
  var PONG = 'DDOSOMI_PONG';
  var SAVE = 'DDOSOMI_SAVE_DRAFT';
  var STUDIO_SOURCE = 'ddosomi-studio';
  var EXT_SOURCE = 'ddosomi-extension';

  function version() {
    try { return chrome.runtime.getManifest().version; } catch (e) { return '1.0.0'; }
  }

  function toPage(obj) {
    try { window.postMessage(obj, location.origin); } catch (e) {
      try { window.postMessage(obj, '*'); } catch (e2) {}
    }
  }

  function pong() {
    toPage({ source: EXT_SOURCE, type: PONG, version: version() });
  }

  function ack(ok, message, tabId) {
    toPage({ source: EXT_SOURCE, type: 'DDOSOMI_SAVE_ACK', ok: !!ok, message: message || '', tabId: tabId || 0 });
  }

  function forwardSave(draft) {
    if (!draft || !draft.blogId) { ack(false, '블로그 ID가 없는 초안이에요'); return; }
    try {
      chrome.runtime.sendMessage({ type: SAVE, draft: draft }, function (resp) {
        if (chrome.runtime.lastError) {
          ack(false, chrome.runtime.lastError.message || '확장 프로그램 연결 오류');
          return;
        }
        if (!resp || !resp.ok) {
          ack(false, (resp && resp.message) || '확장 프로그램이 초안을 받지 못했어요');
          return;
        }
        ack(true, '네이버 글쓰기 탭을 열었어요', resp.tabId);
      });
    } catch (e) {
      ack(false, '확장 프로그램 연결이 끊겼어요 — 새로고침 후 다시 시도해 주세요');
    }
  }

  window.addEventListener('message', function (ev) {
    if (ev.source !== window) { return; }
    var d = ev.data;
    if (!d || d.source !== STUDIO_SOURCE) { return; }
    if (d.type === PING) { pong(); return; }
    if (d.type === SAVE) { forwardSave(d.payload); }
  }, false);

  /* 스튜디오가 페이지를 늦게 그려도 잡히도록 여러 번 응답한다 */
  pong();
  document.addEventListener('DOMContentLoaded', pong);
  window.addEventListener('load', pong);
  setTimeout(pong, 600);
  setTimeout(pong, 1800);
})();
