/* 또소미 네이버 자동 임시저장 — 네이버 글쓰기 화면에서 초안을 입력하고 [저장]만 누른다 */
(function () {
  'use strict';
  if (window.__TTOSOMI_NAVER_LOADED__) { return; }
  window.__TTOSOMI_NAVER_LOADED__ = true;

  var BUILD = window.TtosomiDraft || null;
  var STORE_KEY = 'ddosomiDraft';
  var BANNER_ID = 'ttosomi-naver-banner';
  var MAX_LOG = 7;

  var state = { draft: null, busy: false, logs: [], poll: null };
  var host = null;
  var shadow = null;

  /* ---------- 작은 도구 ---------- */
  function T(s) { return String(s == null ? '' : s); }
  function trim(s) { return T(s).replace(/^\s+|\s+$/g, ''); }
  function short(s, n) { s = T(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
  function q(sel, root) { try { return (root || document).querySelector(sel); } catch (e) { return null; } }
  function qa(sel, root) {
    try { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); } catch (e) { return []; }
  }
  function sleep(ms) { return new Promise(function (res) { setTimeout(res, ms); }); }
  function fire(el, type) {
    try { el.dispatchEvent(new Event(type, { bubbles: true })); } catch (e) {}
  }
  function isVisible(el) {
    if (!el) { return false; }
    try {
      var r = el.getBoundingClientRect();
      if (r.width <= 0 && r.height <= 0) { return false; }
      var st = window.getComputedStyle ? window.getComputedStyle(el) : null;
      if (st && (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0')) { return false; }
      return true;
    } catch (e) { return false; }
  }

  /* ---------- 로그 ---------- */
  function log(msg, kind) {
    state.logs.push({ msg: msg, kind: kind || 'info' });
    while (state.logs.length > MAX_LOG) { state.logs.shift(); }
    renderLog();
  }

  function renderLog() {
    if (!shadow) { return; }
    var ul = shadow.querySelector('[data-k="log"]');
    if (!ul) { return; }
    var html = '';
    for (var i = 0; i < state.logs.length; i++) {
      var l = state.logs[i];
      var mark = l.kind === 'ok' ? '✅ ' : (l.kind === 'warn' ? '⚠️ ' : (l.kind === 'err' ? '⛔ ' : '· '));
      html += '<li class="' + l.kind + '">' + mark + escapeHtml(l.msg) + '</li>';
    }
    ul.innerHTML = html;
    var card = shadow.querySelector('.card');
    if (card && card.scrollHeight) { ul.scrollTop = ul.scrollHeight; }
  }

  function escapeHtml(s) {
    return T(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* ---------- 에디터 찾기 ---------- */
  function isEditable(el) {
    if (!el) { return false; }
    if (el.isContentEditable) { return true; }
    var ce = el.getAttribute ? el.getAttribute('contenteditable') : null;
    return ce === 'true' || ce === '';
  }

  function editableHost(el) {
    var cur = el;
    for (var i = 0; i < 7 && cur; i++) {
      if (isEditable(cur)) { return cur; }
      cur = cur.parentNode;
    }
    return el;
  }

  var TITLE_SELECTORS = [
    '.se-documentTitle .se-text-paragraph',
    '.se-documentTitle [contenteditable="true"]',
    '.se-documentTitle',
    '.se-title-text .se-text-paragraph',
    '.se-title-text',
    '.se-title [contenteditable="true"]',
    '[data-placeholder*="제목"]'
  ];

  var BODY_SELECTORS = [
    '.se-main-container .se-component.se-text .se-component-content',
    '.se-main-container .se-component-content',
    '.se-content .se-component.se-text .se-component-content',
    '.se-content .se-component-content',
    '.se-wrapper .se-component-content',
    '.se-component-content[contenteditable="true"]',
    '#se-main [contenteditable="true"]'
  ];

  function findTitleEl() {
    for (var i = 0; i < TITLE_SELECTORS.length; i++) {
      var el = q(TITLE_SELECTORS[i]);
      if (el && isVisible(el)) { return el; }
    }
    var eds = qa('[contenteditable="true"]');
    for (var j = 0; j < eds.length; j++) {
      var ph = (eds[j].getAttribute && eds[j].getAttribute('data-placeholder')) || '';
      var pph = (eds[j].parentNode && eds[j].parentNode.getAttribute && eds[j].parentNode.getAttribute('data-placeholder')) || '';
      if ((ph + pph).indexOf('제목') >= 0) { return eds[j]; }
    }
    return null;
  }

  function findBodyEl() {
    for (var i = 0; i < BODY_SELECTORS.length; i++) {
      var list = qa(BODY_SELECTORS[i]);
      for (var k = 0; k < list.length; k++) {
        if (isVisible(list[k])) { return list[k]; }
      }
    }
    /* 마지막 수단: 가장 큰 contenteditable (제목 칸 제외) */
    var title = findTitleEl();
    var best = null;
    var bestArea = 0;
    var eds = qa('[contenteditable="true"]');
    for (var j = 0; j < eds.length; j++) {
      var el = eds[j];
      if (!isVisible(el)) { continue; }
      if (title && (el === title || (title.contains && title.contains(el)))) { continue; }
      var r = el.getBoundingClientRect();
      var area = r.width * r.height;
      if (area > bestArea) { bestArea = area; best = el; }
    }
    return best || (title ? null : q('[contenteditable="true"]'));
  }

  function bodyHost() {
    var el = findBodyEl();
    return el ? editableHost(el) : null;
  }

  function placeCaretAtEnd(el) {
    try {
      el.focus();
      var range = document.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (e) {}
  }

  function selectAllIn(el) {
    try {
      el.focus();
      var range = document.createRange();
      range.selectNodeContents(el);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (e) {}
  }

  /* ---------- 입력 ---------- */
  function setTitle(text) {
    var el = findTitleEl();
    if (!el) {
      log('제목 칸을 찾지 못했어요 — 제목은 직접 넣어 주세요', 'warn');
      return false;
    }
    var h = editableHost(el);
    try {
      selectAllIn(h);
      try { document.execCommand('delete', false, null); } catch (e) {}
      var ok = false;
      try { ok = document.execCommand('insertText', false, text); } catch (e2) { ok = false; }
      if (!ok) { h.textContent = text; }
      fire(h, 'input');
      log('제목 입력: ' + short(text, 26));
      return true;
    } catch (e3) {
      log('제목 입력 실패 — 직접 넣어 주세요', 'warn');
      return false;
    }
  }

  function clearBody() {
    var h = bodyHost();
    if (!h) { return false; }
    selectAllIn(h);
    try { document.execCommand('delete', false, null); } catch (e) {}
    return true;
  }

  function insertHtml(html) {
    var h = bodyHost();
    if (!h) { return false; }
    placeCaretAtEnd(h);
    var ok = false;
    try { ok = document.execCommand('insertHTML', false, html); } catch (e) { ok = false; }
    if (!ok) {
      try {
        var sel = window.getSelection();
        if (sel && sel.rangeCount) {
          var range = sel.getRangeAt(0);
          var frag = range.createContextualFragment(html);
          range.deleteContents();
          range.insertNode(frag);
          sel.collapseToEnd();
          ok = true;
        }
      } catch (e2) { ok = false; }
    }
    fire(h, 'input');
    return ok;
  }

  function dataUrlToBlob(dataUrl) {
    return new Promise(function (resolve) {
      try {
        var parts = String(dataUrl).split(',');
        var mime = (parts[0].match(/data:([^;]+)/) || [])[1] || 'image/jpeg';
        var bin = atob(parts[1] || '');
        var len = bin.length;
        var buf = new Uint8Array(len);
        for (var i = 0; i < len; i++) { buf[i] = bin.charCodeAt(i); }
        resolve(new Blob([buf], { type: mime }));
      } catch (e) { resolve(null); }
    });
  }

  function imageCount() {
    return qa('.se-main-container img, .se-content img, .se-component img').length;
  }

  function waitFor(cond, ms) {
    return new Promise(function (resolve) {
      var started = Date.now();
      var tick = function () {
        var v = false;
        try { v = !!cond(); } catch (e) { v = false; }
        if (v) { resolve(true); return; }
        if (Date.now() - started > ms) { resolve(false); return; }
        setTimeout(tick, 220);
      };
      tick();
    });
  }

  function findFileInput() {
    var inputs = qa('input[type="file"]');
    for (var i = 0; i < inputs.length; i++) {
      if (!isVisible(inputs[i])) { continue; }
      return inputs[i];
    }
    return inputs.length ? inputs[inputs.length - 1] : null;
  }

  function insertImage(dataUrl, name) {
    var before = imageCount();
    return dataUrlToBlob(dataUrl).then(function (blob) {
      if (!blob) { return false; }
      var file;
      try {
        file = new File([blob], name || 'photo.jpg', { type: blob.type || 'image/jpeg' });
      } catch (e) {
        file = blob;
        try { file.name = name || 'photo.jpg'; } catch (e2) {}
      }

      /* 1) 붙여넣기(paste)로 사진 컴포넌트 만들기 */
      var h = bodyHost();
      if (h) {
        try {
          var dt = new DataTransfer();
          dt.items.add(file);
          placeCaretAtEnd(h);
          var ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
          h.dispatchEvent(ev);
        } catch (e3) {}
      }

      return waitFor(function () { return imageCount() > before; }, 4500).then(function (ok) {
        if (ok) { return true; }

        /* 2) 끌어놓기(drop) */
        var h2 = bodyHost();
        if (h2) {
          try {
            var dt2 = new DataTransfer();
            dt2.items.add(file);
            placeCaretAtEnd(h2);
            h2.dispatchEvent(new DragEvent('drop', { dataTransfer: dt2, bubbles: true, cancelable: true }));
          } catch (e4) {}
        }
        return waitFor(function () { return imageCount() > before; }, 3500).then(function (ok2) {
          if (ok2) { return true; }

          /* 3) 숨은 file input */
          var input = findFileInput();
          if (input) {
            try {
              var dt3 = new DataTransfer();
              dt3.items.add(file);
              input.files = dt3.files;
              input.dispatchEvent(new Event('change', { bubbles: true }));
            } catch (e5) {}
            return waitFor(function () { return imageCount() > before; }, 4500);
          }
          return false;
        });
      });
    });
  }

  /* ---------- 저장 ---------- */
  function findSaveButton() {
    var nodes = qa('button, a, [role="button"]');
    var fallback = null;
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var txt = T(el.textContent).replace(/\s+/g, '');
      if (!txt || txt.length > 10) { continue; }
      if (/발행|공개|예약/.test(txt)) { continue; }
      if (!isVisible(el)) { continue; }
      if (txt === '임시저장') { return el; }
      if (txt === '저장' || /^저장/.test(txt)) { if (!fallback) { fallback = el; } }
    }
    return fallback;
  }

  function clickSafe(el, what) {
    var label = T(el && el.textContent).replace(/\s+/g, '');
    if (/발행/.test(label)) {
      log('발행 버튼은 누르지 않아요 (안전 장치)', 'warn');
      return false;
    }
    try {
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
      el.dispatchEvent(new MouseEvent('click', { bubbles: true }));
      return true;
    } catch (e) {
      try { el.click(); return true; } catch (e2) { return false; }
    }
  }

  function isSaveDialog(el) {
    var cur = el;
    for (var i = 0; i < 6 && cur; i++) {
      var cls = (cur.className && typeof cur.className === 'string') ? cur.className : '';
      var role = cur.getAttribute ? (cur.getAttribute('role') || '') : '';
      if (/layer|dialog|modal|popup|confirm/i.test(cls) || role === 'dialog') { return true; }
      cur = cur.parentNode;
    }
    return false;
  }

  function confirmSaveDialog() {
    var nodes = qa('button, a, [role="button"]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var txt = T(el.textContent).replace(/\s+/g, '');
      if (!txt || txt.length > 4) { continue; }
      if (/발행/.test(txt)) { continue; }
      if (txt !== '확인' && txt !== '저장' && txt !== '예') { continue; }
      if (!isVisible(el) || !isSaveDialog(el)) { continue; }
      clickSafe(el, 'dialog');
      return true;
    }
    return false;
  }

  function bodyTextSaysSaved() {
    var txt = '';
    try { txt = T(document.body && document.body.innerText).replace(/\s+/g, ''); } catch (e) { return false; }
    return /저장되었습니다|저장되었어요|임시저장되었|임시저장됨/.test(txt);
  }

  function markConsumed() {
    try {
      chrome.runtime.sendMessage({ type: 'DDOSOMI_CONSUMED' }, function () {});
    } catch (e) {}
  }

  /* ---------- 배너 ---------- */
  var BANNER_CSS = ''
    + '.card{width:330px;max-width:calc(100vw - 28px);background:#fff;border:1px solid #dbe6f3;border-radius:16px;'
    + 'box-shadow:0 16px 44px rgba(28,48,78,.28);padding:14px 14px 12px;'
    + 'font-family:-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Malgun Gothic","Noto Sans KR",sans-serif;color:#2b394a;text-align:left;}'
    + '.top{display:flex;align-items:center;gap:7px;margin-bottom:7px;}'
    + '.dot{width:9px;height:9px;border-radius:50%;background:#3cb371;box-shadow:0 0 0 3px #e6f6ec;flex:none;}'
    + '.top b{font-size:13.5px;letter-spacing:-.2px;flex:1;}'
    + '.x{border:none;background:transparent;font-size:14px;color:#9aa8b7;cursor:pointer;padding:2px 4px;line-height:1;}'
    + '.title{margin:0 0 3px;font-size:12.5px;font-weight:800;color:#31506f;line-height:1.45;word-break:break-word;}'
    + '.meta{margin:0 0 10px;font-size:11px;color:#8b9bb0;}'
    + '.btns{display:flex;gap:6px;flex-wrap:wrap;}'
    + '.btns button{font:inherit;font-size:12px;font-weight:800;border-radius:10px;padding:8px 11px;cursor:pointer;border:1px solid #dbe6f3;background:#fff;color:#42607f;}'
    + '.btns button.go{background:#4b7cb3;border-color:#4b7cb3;color:#fff;flex:1;}'
    + '.btns button[disabled]{opacity:.6;cursor:progress;}'
    + '.log{list-style:none;margin:10px 0 0;padding:8px 9px;max-height:118px;overflow:auto;background:#f7fafd;border:1px solid #e8eff7;border-radius:10px;font-size:11px;line-height:1.6;color:#4a5c72;}'
    + '.log:empty{display:none;}'
    + '.log li.ok{color:#2f6b4f;}'
    + '.log li.warn{color:#8a6d1f;}'
    + '.log li.err{color:#a8423e;}'
    + '.note{margin:9px 0 0;font-size:10.5px;color:#9aa8b7;line-height:1.5;}';

  var BANNER_HTML = ''
    + '<div class="card">'
    + '  <div class="top"><span class="dot"></span><b>또소미 자동 입력 준비됨</b><button class="x" data-k="close" title="닫기">✕</button></div>'
    + '  <p class="title" data-k="title">초안을 불러오는 중…</p>'
    + '  <p class="meta" data-k="meta"></p>'
    + '  <div class="btns">'
    + '    <button class="go" data-k="run">자동 채우기 &amp; 임시저장 시작</button>'
    + '    <button data-k="copy">원고 HTML 복사</button>'
    + '  </div>'
    + '  <ul class="log" data-k="log"></ul>'
    + '  <p class="note">발행은 누르지 않아요. 입력이 끝나면 내용을 확인하고 직접 발행해 주세요.</p>'
    + '</div>';

  function ensureBanner() {
    if (host && document.documentElement && document.documentElement.contains(host)) { return true; }
    try {
      host = document.createElement('div');
      host.id = BANNER_ID;
      host.style.cssText = 'position:fixed;right:14px;bottom:14px;z-index:2147483647;';
      shadow = host.attachShadow({ mode: 'open' });
      shadow.innerHTML = '<style>' + BANNER_CSS + '</style>' + BANNER_HTML;

      var closeBtn = shadow.querySelector('[data-k="close"]');
      if (closeBtn) { closeBtn.addEventListener('click', function () { host.style.display = 'none'; }); }
      var runBtn = shadow.querySelector('[data-k="run"]');
      if (runBtn) { runBtn.addEventListener('click', function () { run(); }); }
      var copyBtn = shadow.querySelector('[data-k="copy"]');
      if (copyBtn) { copyBtn.addEventListener('click', function () { copyDraftHtml(); }); }

      (document.body || document.documentElement).appendChild(host);
      return true;
    } catch (e) {
      return false;
    }
  }

  function setRunLabel(text, disabled) {
    if (!shadow) { return; }
    var btn = shadow.querySelector('[data-k="run"]');
    if (!btn) { return; }
    btn.textContent = text;
    btn.disabled = !!disabled;
  }

  function showBanner() {
    if (!state.draft) { return; }
    if (!ensureBanner()) { return; }
    var d = state.draft;
    var titleEl = shadow.querySelector('[data-k="title"]');
    var metaEl = shadow.querySelector('[data-k="meta"]');
    if (titleEl) { titleEl.textContent = short(d.title || '(제목 없음)', 48); }
    if (metaEl) {
      var parts = [];
      if (d.blogName) { parts.push(d.blogName); }
      if (d.blogId) { parts.push('blog.naver.com/' + d.blogId); }
      var secs = (d.sections || []).length;
      parts.push('소제목 ' + secs + '개');
      parts.push('사진 ' + (d.sections || []).filter(function (s) { return s && s.photo; }).length + '장');
      if (d.table && d.table.header && d.table.header.length) { parts.push('요약표'); }
      metaEl.textContent = parts.join(' · ');
    }
    host.style.display = 'block';
    renderLog();
  }

  function copyDraftHtml() {
    if (!BUILD || !state.draft) { return; }
    var html = BUILD.buildHtml(state.draft);
    var plain = BUILD.buildPlain(state.draft);
    var done = function () { log('원고 HTML을 복사했어요 — 본문에 붙여넣으면 서식이 살아나요', 'ok'); };
    try {
      if (navigator.clipboard && window.ClipboardItem) {
        var item = new ClipboardItem({
          'text/html': new Blob([html], { type: 'text/html' }),
          'text/plain': new Blob([plain], { type: 'text/plain' })
        });
        navigator.clipboard.write([item]).then(done, function () { fallbackCopy(plain); });
        return;
      }
    } catch (e) {}
    fallbackCopy(plain);
  }

  function fallbackCopy(text) {
    try {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0;';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      log('원고를 텍스트로 복사했어요', 'ok');
    } catch (e) {
      log('복사가 안 됐어요 — 직접 선택해 복사해 주세요', 'warn');
    }
  }

  /* ---------- 실행 ---------- */
  async function run() {
    if (state.busy) { return; }
    if (!state.draft) {
      log('받은 초안이 없어요. ddosomi_blog ③ 대기함에서 🚀 버튼을 눌러 주세요', 'warn');
      return;
    }
    if (!BUILD) {
      log('입력 도우미 파일을 못 읽었어요. 확장 프로그램을 다시 설치해 주세요', 'err');
      return;
    }

    state.busy = true;
    setRunLabel('입력하는 중…', true);
    log('입력 시작 — ' + short(state.draft.title, 28));

    var d = state.draft;
    var imgOk = 0;
    var imgFail = 0;

    try {
      setTitle(d.title || '');
      await sleep(400);

      if (!bodyHost()) {
        log('본문 편집 영역을 찾지 못했어요. 글쓰기 화면이 다 뜬 뒤 다시 눌러 주세요', 'err');
        return;
      }

      if (!clearBody()) {
        log('본문을 비우지 못했어요 — 빈 글쓰기 화면에서 다시 시도해 주세요', 'warn');
      }
      await sleep(250);

      var blocks = BUILD.buildBlocks(d);
      log('블록 ' + blocks.length + '개 입력 준비');

      for (var i = 0; i < blocks.length; i++) {
        var b = blocks[i];
        if (b.type === 'image') {
          var ok = await insertImage(b.dataUrl, 'ttosomi-photo-' + (i + 1) + '.jpg');
          if (ok) { imgOk++; } else { imgFail++; }
          await sleep(250);
        } else {
          insertHtml(b.html);
          await sleep(55);
        }
      }

      if (imgFail) {
        log('사진 ' + imgOk + '장 입력, ' + imgFail + '장은 자동 입력 실패 — 그 자리에 직접 넣어 주세요', 'warn');
      } else if (imgOk) {
        log('사진 ' + imgOk + '장 입력 완료', 'ok');
      }

      await sleep(700);
      var saveBtn = findSaveButton();
      if (!saveBtn) {
        log('저장 버튼을 찾지 못했어요 — 오른쪽 위 [저장]을 직접 눌러 주세요', 'warn');
        log('본문 입력은 끝났어요. 서체·형광펜·표를 확인해 주세요', 'ok');
        return;
      }

      clickSafe(saveBtn, 'save');
      log('저장 버튼을 눌렀어요');
      await sleep(1600);
      if (confirmSaveDialog()) { log('저장 확인 창에서 [확인]을 눌렀어요'); await sleep(1500); }

      if (bodyTextSaysSaved()) {
        log('임시저장 완료 — 내용을 확인하고 직접 발행해 주세요', 'ok');
      } else {
        log('저장을 눌렀어요. 화면에 “저장되었습니다”가 보이는지 확인해 주세요', 'ok');
      }
      markConsumed();
    } catch (e) {
      log('입력 중 오류: ' + (e && e.message ? e.message : e), 'err');
    } finally {
      state.busy = false;
      setRunLabel('다시 입력', false);
    }
  }

  /* ---------- 시작 ---------- */
  function loadDraft() {
    try {
      chrome.storage.local.get(STORE_KEY, function (data) {
        var rec = data && data[STORE_KEY];
        if (!rec || !rec.draft) { return; }
        state.draft = rec.draft;
        log('초안을 받았어요 — [자동 채우기]를 눌러 주세요');
        showBanner();
      });
    } catch (e) {}
  }

  function startPolling() {
    if (state.poll) { return; }
    var tries = 0;
    state.poll = setInterval(function () {
      tries++;
      if (state.draft && bodyHost()) { showBanner(); }
      if (tries > 90) { clearInterval(state.poll); state.poll = null; }
    }, 1000);
  }

  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === 'local' && changes[STORE_KEY] && changes[STORE_KEY].newValue) {
        state.draft = changes[STORE_KEY].newValue.draft;
        state.logs = [];
        showBanner();
      }
    });
  } catch (e) {}

  loadDraft();
  startPolling();

  window.addEventListener('load', function () {
    if (state.draft && bodyHost()) { showBanner(); }
  });
})();
