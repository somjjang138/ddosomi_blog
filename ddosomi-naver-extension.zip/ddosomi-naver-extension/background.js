/* 또소미 네이버 자동 임시저장 — 백그라운드(서비스 워커)

   · 스튜디오(③ 대기함)에서 받은 초안은 chrome.storage.local에 '1회용·5분'으로 보관한다.
   · 글쓰기 탭이 열리면 에디터 프레임이 스스로 입력을 시작하고, 끝나면 초안을 지운다.
   · 에디터 프레임의 진행 로그를 최상위 프레임(배너)으로 중계한다. */
'use strict';

var STORE_KEY = 'ddosomiDraft';
var TTL_MS = 5 * 60 * 1000;   /* 5분 */

function recTime(rec) {
  if (!rec) { return 0; }
  return Number(rec.createdAt || rec.receivedAt || 0) || 0;
}

function isStale(rec) {
  var t = recTime(rec);
  if (!t) { return true; }
  return (Date.now() - t) > TTL_MS;
}

/* 5분 지난 잔여 초안 청소 — 배너가 계속 뜨는 원인 제거 */
function purgeStale(cb) {
  chrome.storage.local.get(STORE_KEY, function (data) {
    var rec = data && data[STORE_KEY];
    if (rec && isStale(rec)) {
      chrome.storage.local.remove(STORE_KEY, function () { if (cb) { cb(true); } });
      return;
    }
    if (cb) { cb(false); }
  });
}

/* 최상위 프레임(배너)으로 보내기 */
function toTopFrame(tabId, msg) {
  if (tabId === undefined || tabId === null) { return; }
  try {
    chrome.tabs.sendMessage(tabId, msg, { frameId: 0 }, function () { void chrome.runtime.lastError; });
  } catch (e) {}
}

/* 탭의 모든 프레임으로 보내기 (중지·다시 시도) */
function toAllFrames(tabId, msg) {
  if (tabId === undefined || tabId === null) { return; }
  try {
    chrome.tabs.sendMessage(tabId, msg, function () { void chrome.runtime.lastError; });
  } catch (e) {}
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) { return; }

  if (msg.type === 'DDOSOMI_SAVE_DRAFT') {
    var draft = msg.draft || {};
    if (!draft.blogId || !draft.title) {
      sendResponse({ ok: false, message: '초안에 블로그 ID나 제목이 없어요' });
      return true;
    }

    var record = {
      draftId: draft.draftId || '',
      blogId: draft.blogId,
      title: draft.title,
      createdAt: Date.now(),
      receivedAt: Date.now(),
      draft: draft
    };

    chrome.storage.local.set({ ddosomiDraft: record }, function () {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, message: '초안 저장 실패: ' + chrome.runtime.lastError.message });
        return;
      }
      openEditor(draft.blogId, function (tab) {
        try {
          if (chrome.action && chrome.action.setBadgeText) {
            chrome.action.setBadgeText({ text: '1' });
            chrome.action.setBadgeBackgroundColor({ color: '#4b7cb3' });
          }
        } catch (e) {}
        sendResponse({ ok: true, tabId: tab && tab.id, message: 'ok' });
      });
    });
    return true;
  }

  /* 다 쓴 초안은 바로 지운다 (1회용) */
  if (msg.type === 'DDOSOMI_CONSUMED') {
    chrome.storage.local.remove(STORE_KEY);
    try {
      if (chrome.action && chrome.action.setBadgeText) { chrome.action.setBadgeText({ text: '' }); }
    } catch (e) {}
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'DDOSOMI_GET_LAST') {
    chrome.storage.local.get(STORE_KEY, function (data) {
      var rec = data && data[STORE_KEY];
      if (rec && isStale(rec)) {
        chrome.storage.local.remove(STORE_KEY, function () {
          sendResponse({ ok: true, record: null });
        });
        return;
      }
      sendResponse({ ok: true, record: rec || null });
    });
    return true;
  }

  /* 에디터 프레임 → 배너(최상위 프레임) */
  if (msg.type === 'DDOSOMI_RUN_LOG') {
    toTopFrame(sender && sender.tab && sender.tab.id, { type: 'DDOSOMI_RUN_LOG', msg: msg.msg, kind: msg.kind || 'info' });
    return;
  }
  if (msg.type === 'DDOSOMI_RUN_STATE') {
    toTopFrame(sender && sender.tab && sender.tab.id, { type: 'DDOSOMI_RUN_STATE', phase: msg.phase, text: msg.text });
    return;
  }

  /* 배너 → 모든 프레임(중지·다시 시도) */
  if (msg.type === 'DDOSOMI_RUN_STOP' || msg.type === 'DDOSOMI_RUN_RETRY') {
    toAllFrames(sender && sender.tab && sender.tab.id, { type: msg.type });
    sendResponse({ ok: true });
    return true;
  }
});

/* 이미 열린 글쓰기 탭이 있으면 그 탭을 다시 쓰고, 없으면 새로 연다 */
function openEditor(blogId, cb) {
  var url = 'https://blog.naver.com/' + encodeURIComponent(blogId) + '/postwrite';

  chrome.tabs.query({}, function (tabs) {
    var found = null;
    for (var i = 0; i < (tabs || []).length; i++) {
      var t = tabs[i];
      if (t && t.url && /blog\.naver\.com\/.*postwrite/i.test(t.url)) { found = t; break; }
    }
    if (found) {
      chrome.tabs.update(found.id, { url: url, active: true }, function (tab) {
        if (chrome.runtime.lastError) { create(url, cb); return; }
        cb(tab);
      });
      return;
    }
    create(url, cb);
  });
}

function create(url, cb) {
  chrome.tabs.create({ url: url, active: true }, function (tab) {
    cb(tab);
  });
}

chrome.runtime.onInstalled.addListener(function () {
  try { chrome.action.setBadgeText({ text: '' }); } catch (e) {}
  purgeStale();
});

chrome.runtime.onStartup.addListener(function () {
  purgeStale();
});

/* 워커가 깨어날 때마다 한 번 더 청소 */
purgeStale();
