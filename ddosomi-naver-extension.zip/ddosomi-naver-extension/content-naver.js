/* 또소미 네이버 자동 임시저장 — 네이버 글쓰기 화면에서 초안을 넣고 [저장]만 누른다

   · ③ 대기함에서 🚀를 누르면 postwrite 탭이 열리고, 에디터가 뜨는 즉시 자동으로 시작한다.
   · 배너는 진행 로그 + 중지/복사 폴백만 담당한다(다시 버튼을 누를 필요 없음).
   · 넘겨받은 초안은 1회용이고 5분이 지나면 저절로 지워진다(배너가 계속 뜨는 문제 방지).
   · 발행 버튼은 절대 누르지 않는다. 저장(임시저장)만 누른다. */
(function () {
  'use strict';
  if (window.__TTOSOMI_NAVER_LOADED__) { return; }
  window.__TTOSOMI_NAVER_LOADED__ = true;

  var BUILD = window.TtosomiDraft || null;
  var STORE_KEY = 'ddosomiDraft';
  var TTL_MS = 5 * 60 * 1000;          /* 임시저장 초안 수명: 5분 */
  var BANNER_ID = 'ttosomi-naver-banner';
  var MAX_LOG = 14;

  var IS_TOP = (function () { try { return window.top === window; } catch (e) { return false; } })();

  var state = {
    draft: null,
    rec: null,
    busy: false,
    stop: false,
    logs: [],
    autoStarted: false,
    phase: 'idle',
    phaseText: ''
  };
  var host = null;
  var shadow = null;

  /* ---------- 작은 도구 ---------- */
  function T(s) { return String(s == null ? '' : s); }
  function trim(s) { return T(s).replace(/^\s+|\s+$/g, ''); }
  function norm(s) { return T(s).replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, ''); }
  function short(s, n) { s = T(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
  function q(sel, root) { try { return (root || document).querySelector(sel); } catch (e) { return null; } }
  function qa(sel, root) {
    try { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); } catch (e) { return []; }
  }
  function visible(list) {
    var out = [];
    for (var i = 0; i < (list || []).length; i++) { if (isVisible(list[i])) { out.push(list[i]); } }
    return out;
  }
  function sleep(ms) { return new Promise(function (res) { setTimeout(res, ms); }); }
  function fire(el, type) {
    try { el.dispatchEvent(new Event(type, { bubbles: true })); } catch (e) {}
  }
  function isVisible(el) {
    if (!el) { return false; }
    try {
      var r = el.getBoundingClientRect();
      if (r.width <= 0 && r.height <= 0) { return false; }
      var st = window.getComputedStyle ? window.getComputedStyle(el) : null;
      if (st && (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0')) { return false; }
      return true;
    } catch (e) { return false; }
  }
  function tagOf(el) { return el && el.tagName ? String(el.tagName).toUpperCase() : ''; }
  function escapeHtml(s) {
    return T(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* ---------- 확장 프로그램과 대화 ---------- */
  function send(msg) {
    try { chrome.runtime.sendMessage(msg, function () { void chrome.runtime.lastError; }); } catch (e) {}
  }

  /* ---------- 로그 ---------- */
  function log(msg, kind) {
    state.logs.push({ msg: msg, kind: kind || 'info' });
    while (state.logs.length > MAX_LOG) { state.logs.shift(); }
    if (IS_TOP) { renderLog(); } else { send({ type: 'DDOSOMI_RUN_LOG', msg: msg, kind: kind || 'info' }); }
  }

  function setPhase(phase, text) {
    state.phase = phase;
    state.phaseText = text || '';
    if (IS_TOP) { renderPhase(); } else { send({ type: 'DDOSOMI_RUN_STATE', phase: phase, text: text || '' }); }
  }

  function renderLog() {
    if (!shadow) { return; }
    var ul = shadow.querySelector('[data-k="log"]');
    if (!ul) { return; }
    var html = '';
    for (var i = 0; i < state.logs.length; i++) {
      var l = state.logs[i];
      var mark = l.kind === 'ok' ? '✅ ' : (l.kind === 'warn' ? '⚠️ ' : (l.kind === 'err' ? '⛔ ' : '· '));
      html += '<li class="' + l.kind + '">' + mark + escapeHtml(l.msg) + '</li>';
    }
    ul.innerHTML = html;
    try { ul.scrollTop = ul.scrollHeight; } catch (e) {}
  }

  /* ---------- 초안 수명 관리 (1회용 + 5분) ---------- */
  function recTime(rec) {
    if (!rec) { return 0; }
    return Number(rec.createdAt || rec.receivedAt || 0) || 0;
  }
  function isStale(rec) {
    var t = recTime(rec);
    if (!t) { return true; }
    return (Date.now() - t) > TTL_MS;
  }
  function dropStored(reason) {
    try { chrome.storage.local.remove(STORE_KEY, function () {}); } catch (e) {}
    state.draft = null;
    state.rec = null;
    if (reason) { log(reason, 'info'); }
  }
  /* 5분 지난 잔여 초안 청소 — 이게 있어서 평소 글쓰기 화면에 배너가 안 뜬다 */
  function sweepStale() {
    try {
      chrome.storage.local.get(STORE_KEY, function (data) {
        var rec = data && data[STORE_KEY];
        if (rec && isStale(rec)) {
          chrome.storage.local.remove(STORE_KEY, function () {});
        }
      });
    } catch (e) {}
  }

  /* ---------- 에디터 탐색 ---------- */
  function isEditable(el) {
    if (!el) { return false; }
    if (el.isContentEditable) { return true; }
    var ce = el.getAttribute ? el.getAttribute('contenteditable') : null;
    return ce === 'true' || ce === '';
  }

  var TITLE_SELECTORS = [
    '.se-documentTitle .se-text-paragraph',
    '.se-documentTitle [contenteditable="true"]',
    '.se-title-text .se-text-paragraph',
    '.se-title-text',
    '.se-title [contenteditable="true"]',
    '.se-documentTitle',
    '[data-placeholder*="제목"]'
  ];

  function findTitleEl() {
    /* 1) 알려진 선택자 */
    for (var i = 0; i < TITLE_SELECTORS.length; i++) {
      var list = visible(qa(TITLE_SELECTORS[i]));
      if (list.length) { return list[0]; }
    }
    /* 2) '제목' 안내 글자(placeholder)로 찾기 */
    var phs = visible(qa('[class*="placeholder"], [data-placeholder], .se-placeholder'));
    for (var j = 0; j < phs.length; j++) {
      var t = norm(phs[j].textContent) + ' ' + (phs[j].getAttribute ? (phs[j].getAttribute('data-placeholder') || '') : '');
      if (/제목/.test(t)) {
        var hostEl = phs[j].closest ? phs[j].closest('.se-documentTitle, [contenteditable="true"], .se-text-paragraph') : null;
        if (hostEl && isVisible(hostEl)) { return hostEl; }
      }
    }
    /* 3) 가장 위쪽의 contenteditable (제목은 맨 위에 있다) */
    var eds = visible(qa('[contenteditable="true"]'));
    if (!eds.length) { return null; }
    var best = eds[0];
    var bestTop = 1e9;
    for (var k = 0; k < eds.length; k++) {
      try {
        var r = eds[k].getBoundingClientRect();
        if (r.top < bestTop) { bestTop = r.top; best = eds[k]; }
      } catch (e) {}
    }
    return best;
  }

  var BODY_SELECTORS = [
    '.se-main-container .se-component.se-text .se-component-content',
    '.se-main-container .se-text-paragraph',
    '.se-content .se-text-paragraph',
    '.se-text-paragraph',
    '.se-main-container .se-component-content',
    '.se-component-content[contenteditable="true"]',
    '#se-main [contenteditable="true"]'
  ];

  function findBodyHost() {
    for (var i = 0; i < BODY_SELECTORS.length; i++) {
      var list = visible(qa(BODY_SELECTORS[i]));
      if (list.length) { return list[list.length - 1]; }   /* 마지막 글 블록에 이어 쓴다 */
    }
    var title = findTitleEl();
    var eds = visible(qa('[contenteditable="true"]'));
    var pick = null;
    for (var j = 0; j < eds.length; j++) {
      var el = eds[j];
      if (title && (el === title || (title.contains && title.contains(el)))) { continue; }
      pick = el;
    }
    return pick;
  }

  function hasEditor() { return !!(findBodyHost() || findTitleEl()); }

  function paraCount() { return qa('.se-text-paragraph').length + qa('.se-component.se-text').length; }

  /* ---------- 커서 ---------- */
  function placeCaretAtEnd(el) {
    try {
      if (el.focus) { el.focus(); }
      var range = document.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      return true;
    } catch (e) { return false; }
  }

  function selectContents(el) {
    try {
      if (el.focus) { el.focus(); }
      var range = document.createRange();
      range.selectNodeContents(el);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      return true;
    } catch (e) { return false; }
  }

  function clickEl(el) {
    if (!el) { return false; }
    try {
      var r = el.getBoundingClientRect();
      var x = r.left + Math.max(1, Math.min(r.width / 2, 40));
      var y = r.top + Math.max(1, r.height / 2);
      var opt = { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window };
      el.dispatchEvent(new MouseEvent('pointerdown', opt));
      el.dispatchEvent(new MouseEvent('mousedown', opt));
      el.dispatchEvent(new MouseEvent('mouseup', opt));
      el.dispatchEvent(new MouseEvent('click', opt));
      return true;
    } catch (e) {
      try { el.click(); return true; } catch (e2) { return false; }
    }
  }

  /* ---------- 제목 입력 ---------- */
  function titleTextNow() {
    var el = findTitleEl();
    return el ? norm(el.textContent) : '';
  }

  function insertTextInto(el, text) {
    /* 1) execCommand insertText */
    try {
      selectContents(el);
      try { document.execCommand('delete', false, null); } catch (e0) {}
      var ok = false;
      try { ok = document.execCommand('insertText', false, text); } catch (e1) { ok = false; }
      if (ok && titleTextNow().indexOf(norm(text).slice(0, 8)) >= 0) { return true; }
    } catch (e) {}
    /* 2) textContent + input 이벤트 */
    try {
      el.textContent = text;
      fire(el, 'input');
      if (titleTextNow().indexOf(norm(text).slice(0, 8)) >= 0) { return true; }
    } catch (e2) {}
    /* 3) 붙여넣기(paste) */
    try {
      var dt = new DataTransfer();
      dt.setData('text/plain', text);
      selectContents(el);
      el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
      if (titleTextNow().indexOf(norm(text).slice(0, 8)) >= 0) { return true; }
    } catch (e3) {}
    /* 4) beforeinput */
    try {
      el.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: text, bubbles: true, cancelable: true }));
      el.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: text, bubbles: true }));
    } catch (e4) {}
    return titleTextNow().indexOf(norm(text).slice(0, 8)) >= 0;
  }

  function setTitle(text) {
    var want = trim(text);
    if (!want) { return true; }
    var el = findTitleEl();
    if (!el) {
      log('제목 칸을 찾지 못했어요 — 제목만 직접 넣어 주세요', 'warn');
      return false;
    }
    /* 제목 영역을 실제로 클릭해서 커서를 넣는다 */
    clickEl(el);
    var target = el;
    if (isEditable(el)) { target = el; }
    else if (q('[contenteditable="true"]', el)) { target = q('[contenteditable="true"]', el); }
    placeCaretAtEnd(target);
    var ok = insertTextInto(target, want);
    if (!ok && target !== el) { ok = insertTextInto(el, want); }
    if (ok) {
      log('제목 입력: ' + short(want, 26), 'ok');
      return true;
    }
    log('제목이 비어 있어요 — 직접 넣어 주세요', 'warn');
    return false;
  }

  /* ---------- 본문 입력 ---------- */
  function anchorFor(el) {
    if (!el) { return null; }
    if (tagOf(el) === 'P') { return el.parentNode || el; }
    return el;
  }

  function insertHtmlAt(el, html) {
    if (!el) { return false; }
    placeCaretAtEnd(el);
    var ok = false;
    try { ok = document.execCommand('insertHTML', false, html); } catch (e) { ok = false; }
    if (!ok) {
      try {
        var sel = window.getSelection();
        if (sel && sel.rangeCount) {
          var range = sel.getRangeAt(0);
          var frag = range.createContextualFragment(html);
          range.deleteContents();
          range.insertNode(frag);
          sel.collapseToEnd();
          ok = true;
        }
      } catch (e2) { ok = false; }
    }
    return ok;
  }

  function insertHtmlAfter(el, html) {
    try {
      var r = document.createRange();
      r.setStartAfter(el);
      r.collapse(true);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
      var ok = false;
      try { ok = document.execCommand('insertHTML', false, html); } catch (e) { ok = false; }
      if (!ok) {
        var frag = r.createContextualFragment(html);
        r.insertNode(frag);
        ok = true;
      }
      return ok;
    } catch (e2) { return false; }
  }

  /* 본문 비우기 (다시 시도할 때 중복 입력 방지) */
  function clearBody() {
    var ps = bodyParagraphs();
    if (ps.length) {
      try {
        var r = document.createRange();
        r.setStart(ps[0], 0);
        var last = ps[ps.length - 1];
        r.setEnd(last, last.childNodes.length);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(r);
        document.execCommand('delete', false, null);
        return true;
      } catch (e) {}
    }
    var hostEl = findBodyHost();
    if (hostEl) { placeCaretAtEnd(hostEl); return true; }
    return false;
  }

  /* 문단 하나 추가 — 실제 에디터처럼 문단을 나눠서 넣는다 */
  async function appendParagraph(text) {
    var hostEl = findBodyHost();
    if (!hostEl) { return false; }
    var inline = BUILD ? BUILD.inline(text) : escapeHtml(text);

    if (tagOf(hostEl) !== 'P') {
      /* 컴포넌트 단위(contenteditable이 컨테이너)면 블록 HTML 그대로 */
      return insertHtmlAt(hostEl, BUILD ? BUILD.paragraph(text) : '<p>' + inline + '</p>');
    }

    if (norm(hostEl.textContent)) {
      placeCaretAtEnd(hostEl);
      var before = paraCount();
      try { document.execCommand('insertParagraph', false, null); } catch (e) {}
      await sleep(80);
      var next = findBodyHost();
      if (paraCount() > before && next && next !== hostEl) { hostEl = next; }
      else { return insertHtmlAfter(hostEl, BUILD ? BUILD.paragraph(text) : '<p>' + inline + '</p>'); }
    }

    placeCaretAtEnd(hostEl);
    var ok = false;
    try { ok = document.execCommand('insertHTML', false, inline); } catch (e2) { ok = false; }
    if (!ok) {
      try { ok = document.execCommand('insertText', false, text.replace(/==/g, '')); } catch (e3) { ok = false; }
    }
    return ok;
  }

  /* ---------- 표 ---------- */
  async function appendTable(t) {
    var hostEl = findBodyHost();
    if (!hostEl) { return false; }
    var html = BUILD ? BUILD.table(t) : '';
    if (!html) { return false; }
    if (tagOf(hostEl) === 'P') {
      placeCaretAtEnd(hostEl);
      var before = paraCount();
      try { document.execCommand('insertParagraph', false, null); } catch (e) {}
      await sleep(80);
      if (paraCount() > before) { hostEl = findBodyHost(); }
      if (tagOf(hostEl) === 'P' && norm(hostEl.textContent)) { return insertHtmlAfter(hostEl, html); }
      if (tagOf(hostEl) !== 'P') { return insertHtmlAt(hostEl, html); }
    }
    return insertHtmlAt(hostEl, html);
  }

  /* ---------- 사진 ---------- */
  function imageCount() {
    return qa('.se-main-container img, .se-content img, .se-component img').length;
  }

  function waitFor(cond, ms) {
    return new Promise(function (resolve) {
      var started = Date.now();
      var tick = function () {
        var v = false;
        try { v = !!cond(); } catch (e) { v = false; }
        if (v) { resolve(true); return; }
        if (Date.now() - started > ms) { resolve(false); return; }
        setTimeout(tick, 220);
      };
      tick();
    });
  }

  function dataUrlToBlob(dataUrl) {
    return new Promise(function (resolve) {
      try {
        var parts = String(dataUrl).split(',');
        var mime = (parts[0].match(/data:([^;]+)/) || [])[1] || 'image/jpeg';
        var bin = atob(parts[1] || '');
        var len = bin.length;
        var buf = new Uint8Array(len);
        for (var i = 0; i < len; i++) { buf[i] = bin.charCodeAt(i); }
        resolve(new Blob([buf], { type: mime }));
      } catch (e) { resolve(null); }
    });
  }

  function findFileInput() {
    var inputs = qa('input[type="file"]');
    for (var i = 0; i < inputs.length; i++) {
      if (isVisible(inputs[i])) { return inputs[i]; }
    }
    return inputs.length ? inputs[inputs.length - 1] : null;
  }

  function insertImage(dataUrl, name) {
    var before = imageCount();
    return dataUrlToBlob(dataUrl).then(function (blob) {
      if (!blob) { return false; }
      var file;
      try {
        file = new File([blob], name || 'photo.jpg', { type: blob.type || 'image/jpeg' });
      } catch (e) {
        file = blob;
        try { file.name = name || 'photo.jpg'; } catch (e2) {}
      }

      /* 1) 붙여넣기 */
      var h = findBodyHost();
      if (h) {
        try {
          var dt = new DataTransfer();
          dt.items.add(file);
          placeCaretAtEnd(h);
          h.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
        } catch (e3) {}
      }
      return waitFor(function () { return imageCount() > before; }, 5000).then(function (ok) {
        if (ok) { return true; }

        /* 2) 끌어놓기 */
        var h2 = findBodyHost();
        if (h2) {
          try {
            var dt2 = new DataTransfer();
            dt2.items.add(file);
            placeCaretAtEnd(h2);
            h2.dispatchEvent(new DragEvent('drop', { dataTransfer: dt2, bubbles: true, cancelable: true }));
          } catch (e4) {}
        }
        return waitFor(function () { return imageCount() > before; }, 4000).then(function (ok2) {
          if (ok2) { return true; }

          /* 3) 숨은 file input */
          var input = findFileInput();
          if (input) {
            try {
              var dt3 = new DataTransfer();
              dt3.items.add(file);
              input.files = dt3.files;
              input.dispatchEvent(new Event('change', { bubbles: true }));
            } catch (e5) {}
            return waitFor(function () { return imageCount() > before; }, 5000);
          }
          return false;
        });
      });
    });
  }

  /* ---------- 툴바 조작 (서체·크기·정렬·인용구) ---------- */
  function tbNodes() {
    var roots = visible(qa('.se-toolbar, [role="toolbar"], .se-toolbar-wrapper, .se-toolbar-inline, .se-toolbar-area'));
    var list = [];
    for (var i = 0; i < roots.length; i++) {
      list = list.concat(visible(qa('button, [role="button"], a', roots[i])));
    }
    if (!list.length) { list = visible(qa('.se-toolbar button, [role="toolbar"] button')); }
    return list;
  }

  function tbText(el) {
    var parts = [];
    var attrs = ['data-name', 'name', 'aria-label', 'title', 'data-title', 'data-tooltip'];
    for (var i = 0; i < attrs.length; i++) {
      if (el && el.getAttribute) { parts.push(T(el.getAttribute(attrs[i]))); }
    }
    parts.push(T(el && el.textContent));
    return parts.join(' ');
  }

  function tbFind(reName, reLabel) {
    var list = tbNodes();
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      var name = (el.getAttribute && T(el.getAttribute('data-name'))) || '';
      if (reName && reName.test(name)) { return el; }
      if (reLabel && reLabel.test(tbText(el))) { return el; }
    }
    return null;
  }

  function menuScope() {
    var sels = ['.se-dropdown-list', '.se-selectbox-list', '.se-toolbar-select-list', '[role="listbox"]', '[role="menu"]', '.se-toolbar-layer', '.se-popup'];
    for (var i = 0; i < sels.length; i++) {
      var list = visible(qa(sels[i]));
      if (list.length) { return list[list.length - 1]; }
    }
    return null;
  }

  function nodesWithText(labels, root) {
    var out = [];
    var scope = root || menuScope() || document;
    var nodes = qa('button, li, [role="option"], [role="menuitem"], a, span, div', scope);
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!isVisible(el)) { continue; }
      var t = norm(el.textContent);
      if (!t) { continue; }
      for (var j = 0; j < labels.length; j++) {
        if (t === labels[j]) {
          var r = el.getBoundingClientRect();
          out.push({ el: el, area: Math.max(1, r.width * r.height) });
          break;
        }
      }
    }
    out.sort(function (a, b) { return a.area - b.area; });
    var els = [];
    for (var k = 0; k < out.length; k++) { els.push(out[k].el); }
    return els;
  }

  async function pickFromMenu(labels, exclude, waitMs) {
    var deadline = Date.now() + (waitMs || 2400);
    while (Date.now() < deadline) {
      var scope = menuScope();
      var list = nodesWithText(labels, scope || document);
      for (var i = 0; i < list.length; i++) {
        if (exclude && exclude.indexOf(list[i]) >= 0) { continue; }
        clickEl(list[i]);
        return list[i];
      }
      await sleep(120);
    }
    return null;
  }

  /* 서체 */
  async function applyFont(name) {
    var btn = tbFind(/font-?family|font-?name/i, /글꼴|서체|폰트/);
    var exclude = nodesWithText([name]);
    if (!btn) {
      /* 드롭다운 버튼에는 현재 서체 이름이 보인다 */
      var cur = tbFind(null, /나눔고딕|나눔바른고딕|맑은 고딕|기본서체|Noto Sans/);
      btn = cur;
    }
    if (!btn) { return false; }
    clickEl(btn);
    await sleep(180);
    var picked = await pickFromMenu([name, name + ' Regular'], exclude, 2600);
    if (!picked) { return false; }
    await sleep(200);
    return true;
  }

  /* 글자 크기 */
  async function applySize(pt) {
    var label = String(pt);
    var btn = tbFind(/font-?size|font-?size/i, /글자 크기|글씨 크기|크기/);
    if (!btn) {
      /* 크기 드롭다운에는 현재 숫자가 보인다 */
      var list = tbNodes();
      for (var i = 0; i < list.length; i++) {
        var t = norm(list[i].textContent);
        if (/^\d{1,2}$/.test(t)) { btn = list[i]; break; }
      }
    }
    if (!btn) { return false; }
    var exclude = nodesWithText([label]);
    clickEl(btn);
    await sleep(180);
    var picked = await pickFromMenu([label, label + 'pt', label + ' pt'], exclude, 2600);
    if (!picked) { return false; }
    await sleep(200);
    return true;
  }

  /* 가운데 정렬 */
  async function applyAlignCenter() {
    var direct = tbFind(/align-?center|text-?align-?center/i, /가운데\s*정렬|중앙\s*정렬/);
    if (direct) { clickEl(direct); await sleep(150); return true; }
    var dd = tbFind(/align/i, /정렬/);
    if (!dd) { return false; }
    var exclude = nodesWithText(['가운데 정렬', '가운데']);
    clickEl(dd);
    await sleep(180);
    var picked = await pickFromMenu(['가운데 정렬', '가운데'], exclude, 2400);
    return !!picked;
  }

  /* 본문 전체에 서체·크기·정렬을 한 번에 (제목 칸은 건드리지 않는다) */
  function bodyParagraphs() {
    var all = visible(qa('.se-text-paragraph'));
    var out = [];
    for (var i = 0; i < all.length; i++) {
      var p = all[i];
      var inTitle = p.closest ? p.closest('.se-documentTitle, .se-title-text, .se-title') : null;
      if (inTitle) { continue; }
      out.push(p);
    }
    return out;
  }

  async function applyBodyStyle() {
    var paragraphs = bodyParagraphs();
    var first = paragraphs.length ? paragraphs[0] : findBodyHost();
    if (!first) { return { font: false, size: false, align: false }; }

    /* 본문 글 전체를 선택 (제목은 건드리지 않는다) */
    var selected = false;
    try {
      if (paragraphs.length > 1) {
        var range = document.createRange();
        range.setStart(paragraphs[0], 0);
        var lastP = paragraphs[paragraphs.length - 1];
        range.setEnd(lastP, lastP.childNodes.length);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        selected = true;
      } else {
        selected = selectContents(first);
      }
    } catch (e) { selected = false; }
    if (!selected) { selectContents(first); }
    await sleep(120);

    var font = await applyFont('나눔바른고딕');
    var size = await applySize(BUILD && BUILD.SIZES ? BUILD.SIZES.body : 15);
    var align = await applyAlignCenter();
    return { font: font, size: size, align: align };
  }

  function styleReport() {
    var paragraphs = bodyParagraphs();
    if (!paragraphs.length) { return ''; }
    try {
      var st = window.getComputedStyle ? window.getComputedStyle(paragraphs[0]) : null;
      if (!st) { return ''; }
      var fam = String(st.fontFamily || '').split(',')[0].replace(/["']/g, '');
      var size = String(st.fontSize || '');
      var align = String(st.textAlign || '');
      return (fam || '?') + ' · ' + size + (align ? ' · ' + align : '');
    } catch (e) { return ''; }
  }

  /* 표 셀 13pt / 헤더 15pt */
  async function styleTable() {
    var tbls = visible(qa('.se-main-container table, .se-component table, table'));
    if (!tbls.length) { return false; }
    var tbl = tbls[tbls.length - 1];
    var cellPt = BUILD && BUILD.SIZES ? BUILD.SIZES.cell : 13;
    var headPt = BUILD && BUILD.SIZES ? BUILD.SIZES.head : 15;
    try {
      var range = document.createRange();
      range.selectNodeContents(tbl);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (e) { return false; }
    await sleep(100);
    var ok = await applySize(cellPt);
    try {
      var rows = tbl.querySelectorAll('tr');
      if (rows.length) {
        var r2 = document.createRange();
        r2.setStart(rows[0], 0);
        r2.setEnd(rows[0], rows[0].childNodes.length);
        var sel2 = window.getSelection();
        sel2.removeAllRanges();
        sel2.addRange(r2);
        await sleep(80);
        await applySize(headPt);
      }
    } catch (e2) {}
    return ok;
  }

  /* ---------- 인용구 ---------- */
  function findParagraphByText(target) {
    var want = norm(target);
    var nodes = visible(qa('.se-text-paragraph, .se-main-container p, .se-main-container div.se-module-text > p'));
    var best = null;
    for (var i = 0; i < nodes.length; i++) {
      if (norm(nodes[i].textContent) !== want) { continue; }
      /* 안쪽(자식 중 같은 글자를 가진 요소가 없는) 것을 고른다 */
      var inner = false;
      var kids = nodes[i].children || [];
      for (var k = 0; k < kids.length; k++) {
        if (norm(kids[k].textContent) === want) { inner = true; break; }
      }
      if (!inner) { best = nodes[i]; }
    }
    return best;
  }

  async function convertQuotes(quotes) {
    if (!quotes || !quotes.length) { return { ok: 0, total: 0 }; }
    var ok = 0;
    for (var i = 0; i < quotes.length; i++) {
      if (state.stop) { break; }
      var el = findParagraphByText(quotes[i]);
      if (!el) {
        log('소제목 자리를 못 찾았어요: ' + short(quotes[i], 18), 'warn');
        continue;
      }
      clickEl(el);
      placeCaretAtEnd(el);
      await sleep(120);
      var btn = tbFind(/quot/i, /인용구|인용|quote/i);
      if (!btn) {
        log('인용구 버튼을 찾지 못했어요 — 툴바가 접혀 있으면 [더보기]를 펼친 뒤 다시 시도해 주세요', 'warn');
        break;
      }
      clickEl(btn);
      await sleep(320);
      ok++;
    }
    if (ok === quotes.length) {
      log('인용구 ' + ok + '개를 네이버 인용구 블록으로 바꿨어요', 'ok');
    } else if (ok) {
      log('인용구 ' + ok + '/' + quotes.length + '개 적용 — 나머지는 직접 [인용구]를 눌러 주세요', 'warn');
    }
    return { ok: ok, total: quotes.length };
  }

  /* ---------- 저장 ---------- */
  function isDangerLabel(txt) {
    return /발행|공개|예약|게시/.test(txt);
  }

  function findSaveButton() {
    var nodes = visible(qa('button, a, [role="button"]'));
    var fallback = null;
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var txt = norm(el.textContent);
      if (!txt || txt.length > 10) { continue; }
      if (isDangerLabel(txt)) { continue; }
      if (txt === '임시저장') { return el; }
      if (txt === '저장' || /^저장$/.test(txt)) { if (!fallback) { fallback = el; } }
    }
    return fallback;
  }

  function clickSafe(el) {
    var label = norm(el && el.textContent);
    if (isDangerLabel(label)) {
      log('발행 버튼은 누르지 않아요 (안전 장치)', 'warn');
      return false;
    }
    return clickEl(el);
  }

  function inDialog(el) {
    var cur = el;
    for (var i = 0; i < 7 && cur; i++) {
      var cls = (cur.className && typeof cur.className === 'string') ? cur.className : '';
      var role = cur.getAttribute ? T(cur.getAttribute('role')) : '';
      if (/layer|dialog|modal|popup|confirm/i.test(cls) || role === 'dialog') { return true; }
      cur = cur.parentNode;
    }
    return false;
  }

  function confirmSaveDialog() {
    var nodes = visible(qa('button, a, [role="button"]'));
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var txt = norm(el.textContent);
      if (!txt || txt.length > 4) { continue; }
      if (isDangerLabel(txt)) { continue; }
      if (txt !== '확인' && txt !== '저장' && txt !== '예') { continue; }
      if (!inDialog(el)) { continue; }
      clickSafe(el);
      return true;
    }
    return false;
  }

  function bodySaysSaved() {
    var txt = '';
    try { txt = norm(document.body && document.body.innerText); } catch (e) { return false; }
    return /저장되었습니다|저장되었어요|임시저장되었|임시저장됨/.test(txt);
  }

  function markConsumed() {
    send({ type: 'DDOSOMI_CONSUMED' });
  }

  /* ---------- 배너 (최상위 프레임에만) ---------- */
  var BANNER_CSS = ''
    + '.card{width:340px;max-width:calc(100vw - 28px);background:#fff;border:1px solid #dbe6f3;border-radius:16px;'
    + 'box-shadow:0 16px 44px rgba(28,48,78,.28);padding:14px 14px 12px;'
    + 'font-family:-apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo","Malgun Gothic","Noto Sans KR",sans-serif;color:#2b394a;text-align:left;}'
    + '.top{display:flex;align-items:center;gap:7px;margin-bottom:7px;}'
    + '.dot{width:9px;height:9px;border-radius:50%;background:#3cb371;box-shadow:0 0 0 3px #e6f6ec;flex:none;}'
    + '.top b{font-size:13.5px;letter-spacing:-.2px;flex:1;}'
    + '.x{border:none;background:transparent;font-size:14px;color:#9aa8b7;cursor:pointer;padding:2px 4px;line-height:1;}'
    + '.title{margin:0 0 3px;font-size:12.5px;font-weight:800;color:#31506f;line-height:1.45;word-break:break-word;}'
    + '.phase{margin:0 0 9px;font-size:11.5px;font-weight:700;color:#4b7cb3;}'
    + '.phase.err{color:#a8423e;}'
    + '.phase.ok{color:#2f6b4f;}'
    + '.btns{display:flex;gap:6px;flex-wrap:wrap;}'
    + '.btns button{font:inherit;font-size:12px;font-weight:800;border-radius:10px;padding:8px 11px;cursor:pointer;border:1px solid #dbe6f3;background:#fff;color:#42607f;}'
    + '.btns button.warn{color:#a8423e;border-color:#f0cfcd;}'
    + '.btns button[disabled]{opacity:.55;cursor:default;}'
    + '.log{list-style:none;margin:10px 0 0;padding:8px 9px;max-height:130px;overflow:auto;background:#f7fafd;border:1px solid #e8eff7;border-radius:10px;font-size:11px;line-height:1.6;color:#4a5c72;}'
    + '.log:empty{display:none;}'
    + '.log li.ok{color:#2f6b4f;}'
    + '.log li.warn{color:#8a6d1f;}'
    + '.log li.err{color:#a8423e;}'
    + '.note{margin:9px 0 0;font-size:10.5px;color:#9aa8b7;line-height:1.5;}';

  var BANNER_HTML = ''
    + '<div class="card">'
    + '  <div class="top"><span class="dot"></span><b>또소미 자동 입력</b><button class="x" data-k="close" title="닫기">✕</button></div>'
    + '  <p class="title" data-k="title"></p>'
    + '  <p class="phase" data-k="phase">에디터를 기다리는 중…</p>'
    + '  <div class="btns">'
    + '    <button data-k="stop">⏹ 중지</button>'
    + '    <button data-k="copy">📋 원고 HTML 복사</button>'
    + '    <button data-k="retry" hidden>🔁 다시 시도</button>'
    + '  </div>'
    + '  <ul class="log" data-k="log"></ul>'
    + '  <p class="note">발행은 누르지 않아요. 입력이 끝나면 내용을 확인하고 직접 발행해 주세요.</p>'
    + '</div>';

  function ensureBanner() {
    if (host && document.documentElement && document.documentElement.contains(host)) { return true; }
    try {
      host = document.createElement('div');
      host.id = BANNER_ID;
      host.style.cssText = 'position:fixed;right:14px;bottom:14px;z-index:2147483647;';
      shadow = host.attachShadow({ mode: 'open' });
      shadow.innerHTML = '<style>' + BANNER_CSS + '</style>' + BANNER_HTML;

      var closeBtn = shadow.querySelector('[data-k="close"]');
      if (closeBtn) { closeBtn.addEventListener('click', function () { closeBanner(); }); }
      var stopBtn = shadow.querySelector('[data-k="stop"]');
      if (stopBtn) { stopBtn.addEventListener('click', function () { requestStop(); }); }
      var copyBtn = shadow.querySelector('[data-k="copy"]');
      if (copyBtn) { copyBtn.addEventListener('click', function () { copyDraftHtml(); }); }
      var retryBtn = shadow.querySelector('[data-k="retry"]');
      if (retryBtn) { retryBtn.addEventListener('click', function () { requestRetry(); }); }

      document.body.appendChild(host);
      return true;
    } catch (e) { return false; }
  }

  function renderPhase() {
    if (!shadow) { return; }
    var el = shadow.querySelector('[data-k="phase"]');
    if (!el) { return; }
    var cls = 'phase';
    if (state.phase === 'error') { cls += ' err'; }
    if (state.phase === 'done') { cls += ' ok'; }
    el.className = cls;
    el.textContent = state.phaseText || '입력 중…';
    var retry = shadow.querySelector('[data-k="retry"]');
    if (retry) { retry.hidden = !(state.phase === 'error' || state.phase === 'stopped' || state.phase === 'idle'); }
    var stopBtn = shadow.querySelector('[data-k="stop"]');
    if (stopBtn) { stopBtn.disabled = state.phase === 'done' || state.phase === 'error'; }
  }

  function showBanner() {
    if (!IS_TOP || !ensureBanner()) { return; }
    var d = state.draft;
    var titleEl = shadow.querySelector('[data-k="title"]');
    if (titleEl) { titleEl.textContent = d ? short(d.title || '(제목 없음)', 52) : ''; }
    renderPhase();
    renderLog();
    host.style.display = 'block';
  }

  function hideBanner() {
    if (host) { host.style.display = 'none'; }
  }

  /* ✕ 를 누르면 배너와 함께 저장된 초안도 지운다(다음에 글쓰기 열 때 다시 안 뜨게) */
  function closeBanner() {
    hideBanner();
    state.draft = null;
    state.rec = null;
    state.autoStarted = true;
    try { chrome.storage.local.remove(STORE_KEY, function () {}); } catch (e) {}
  }

  function copyDraftHtml() {
    if (!BUILD || !state.draft) { log('복사할 원고가 없어요', 'warn'); return; }
    var html = BUILD.buildHtml(state.draft);
    var plain = BUILD.buildPlain(state.draft);
    var done = function () { log('원고 HTML을 복사했어요 — 본문에 붙여넣으면 서식이 살아나요', 'ok'); };
    try {
      if (navigator.clipboard && window.ClipboardItem) {
        var item = new ClipboardItem({
          'text/html': new Blob([html], { type: 'text/html' }),
          'text/plain': new Blob([plain], { type: 'text/plain' })
        });
        navigator.clipboard.write([item]).then(done, function () { fallbackCopy(plain); });
        return;
      }
    } catch (e) {}
    fallbackCopy(plain);
  }

  function fallbackCopy(text) {
    try {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0;';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      log('원고를 텍스트로 복사했어요', 'ok');
    } catch (e) {
      log('복사가 안 됐어요 — 직접 선택해 복사해 주세요', 'warn');
    }
  }

  function requestStop() {
    state.stop = true;
    log('중지 요청 — 안전한 곳에서 멈출게요', 'warn');
  }

  function requestRetry() {
    if (IS_TOP && !hasEditor()) {
      /* 최상위 프레임은 에디터 프레임에 다시 하라고 알린다 */
      send({ type: 'DDOSOMI_RUN_RETRY' });
      setPhase('idle', '다시 시도할게요…');
      return;
    }
    if (!state.busy) {
      state.stop = false;
      state.autoStarted = true;
      run('retry');
    }
  }

  /* ---------- 실행 ---------- */
  async function run(mode) {
    if (state.busy) { return; }
    if (!state.draft) {
      log('받은 초안이 없어요. ddosomi_blog ③ 대기함에서 🚀 버튼을 눌러 주세요', 'warn');
      setPhase('idle', '초안 없음');
      return;
    }
    if (!BUILD) {
      log('입력 도우미 파일을 못 읽었어요. 확장 프로그램을 다시 설치해 주세요', 'err');
      setPhase('error', '도우미 파일 없음');
      return;
    }

    state.busy = true;
    state.stop = false;
    state.logs = [];
    setPhase('run', '자동 입력을 시작했어요…');
    log('자동 입력 시작 — ' + short(state.draft.title, 28));

    var d = state.draft;
    var imgOk = 0;
    var imgFail = 0;

    try {
      /* 0) 에디터 준비 */
      var ready = await waitFor(function () { return hasEditor(); }, 45000);
      if (!ready) {
        log('에디터를 찾지 못했어요 — 글쓰기 화면이 다 뜬 뒤 [다시 시도]를 눌러 주세요', 'err');
        setPhase('error', '에디터를 찾지 못했어요');
        return;
      }
      await sleep(500);

      /* 받은 초안은 1회용 — 여기서 바로 지워서 다음에 배너가 다시 뜨지 않게 한다 */
      try { chrome.storage.local.remove(STORE_KEY, function () {}); } catch (e0) {}

      if (mode === 'retry') {
        if (clearBody()) { log('기존 본문을 지우고 다시 넣어요'); }
        await sleep(300);
      }

      /* 1) 제목 */
      setTitle(d.title || '');
      await sleep(350);

      if (!findBodyHost()) {
        log('본문 편집 영역을 찾지 못했어요 — 글쓰기 화면이 다 뜬 뒤 [다시 시도]를 눌러 주세요', 'err');
        setPhase('error', '본문 영역을 찾지 못했어요');
        return;
      }

      /* 2) 블록 입력 */
      var blocks = BUILD.buildBlocks(d);
      var quotes = [];
      log('블록 ' + blocks.length + '개 입력 준비');

      for (var i = 0; i < blocks.length; i++) {
        if (state.stop) { break; }
        var b = blocks[i];
        if (b.type === 'image') {
          var ok = await insertImage(b.dataUrl, 'ttosomi-photo-' + (i + 1) + '.jpg');
          if (ok) { imgOk++; } else { imgFail++; }
          await sleep(200);
        } else if (b.type === 'quote') {
          await appendParagraph(b.text);
          quotes.push(b.text);
          await sleep(70);
        } else if (b.type === 'table') {
          await appendTable(b);
          await sleep(150);
        } else if (b.type === 'paragraph') {
          await appendParagraph(b.text);
          await sleep(60);
        } else if (b.type === 'tags') {
          /* 해시태그는 블록 마지막 문단으로 */
          await appendParagraph(b.list.join(' '));
          await sleep(60);
        }
      }

      if (imgFail) {
        log('사진 ' + imgOk + '장 입력, ' + imgFail + '장은 자동 입력 실패 — 그 자리에 직접 넣어 주세요', 'warn');
      } else if (imgOk) {
        log('사진 ' + imgOk + '장 입력 완료', 'ok');
      }

      /* 3) 본문 서체·크기·정렬 */
      setPhase('run', '서체·크기를 맞추는 중…');
      var styled = await applyBodyStyle();
      var rep = styleReport();
      if (styled.font && styled.size) { log('나눔바른고딕 · 15pt · 가운데 정렬 적용', 'ok'); }
      else if (styled.font || styled.size) { log('서체·정렬 일부만 적용됐어요 — 본문을 확인해 주세요', 'warn'); }
      else { log('자동 서체 적용이 안 됐어요 — 본문을 전체 선택해 나눔바른고딕 15pt로 맞춰 주세요', 'warn'); }
      if (rep) { log('본문 확인: ' + rep); }

      /* 4) 표 */
      if (d.table && d.table.header && d.table.header.length) {
        var tableOk = await styleTable();
        log(tableOk ? '표 글자를 13pt로 맞췄어요' : '표 글자 크기는 직접 13pt로 맞춰 주세요', tableOk ? 'ok' : 'warn');
      }

      /* 5) 인용구 */
      if (quotes.length) {
        setPhase('run', '소제목을 인용구로 바꾸는 중…');
        await convertQuotes(quotes);
      }

      if (state.stop) {
        setPhase('stopped', '중지했어요 — 내용은 그대로 남아 있어요');
        log('여기서 멈췄어요. [저장]을 직접 눌러 주세요', 'warn');
        return;
      }

      /* 6) 임시저장 */
      setPhase('run', '임시저장을 누르는 중…');
      await sleep(600);
      var saveBtn = findSaveButton();
      if (!saveBtn) {
        log('저장 버튼을 찾지 못했어요 — 오른쪽 위 [저장]을 직접 눌러 주세요', 'warn');
        setPhase('done', '입력 완료 — 저장만 직접 눌러 주세요');
        return;
      }

      clickSafe(saveBtn);
      log('저장(임시저장) 버튼을 눌렀어요');
      await sleep(1600);
      if (confirmSaveDialog()) { log('저장 확인 창에서 [확인]을 눌렀어요'); await sleep(1500); }

      if (bodySaysSaved()) {
        setPhase('done', '임시저장 완료 — 확인하고 직접 발행해 주세요');
        log('임시저장 완료 — 내용을 확인하고 직접 발행해 주세요', 'ok');
      } else {
        setPhase('done', '저장을 눌렀어요 — 화면의 “저장되었습니다”를 확인해 주세요');
        log('저장을 눌렀어요. 화면에 “저장되었습니다”가 보이는지 확인해 주세요', 'ok');
      }

      /* 1회용: 다 쓴 초안은 바로 지운다 */
      markConsumed();
      try { chrome.storage.local.remove(STORE_KEY, function () {}); } catch (e) {}
    } catch (e) {
      log('입력 중 오류: ' + (e && e.message ? e.message : e), 'err');
      setPhase('error', '오류가 났어요 — 위 로그를 확인해 주세요');
    } finally {
      state.busy = false;
      state.autoStarted = true;
      renderPhase();
    }
  }

  /* ---------- 시작 ---------- */
  function adoptDraft(rec) {
    if (!rec || !rec.draft) { return false; }
    if (isStale(rec)) {
      dropStored('5분이 지난 초안은 지웠어요');
      hideBanner();
      return false;
    }
    state.rec = rec;
    state.draft = rec.draft;
    state.autoStarted = false;
    if (state.phase === 'idle' && !state.phaseText) { state.phaseText = '에디터가 뜨면 자동으로 입력을 시작해요'; }
    if (IS_TOP) { showBanner(); }
    return true;
  }

  function loadDraft() {
    try {
      chrome.storage.local.get(STORE_KEY, function (data) {
        var rec = data && data[STORE_KEY];
        if (!rec || !rec.draft) { return; }
        adoptDraft(rec);
        if (!IS_TOP) { tryAutoStart(); }
      });
    } catch (e) {}
  }

  /* 에디터가 늦게 떠도 잡아서 자동 시작 */
  function startPolling() {
    var tries = 0;
    var timer = setInterval(function () {
      tries++;
      if (state.draft && !state.autoStarted && !state.busy && hasEditor()) {
        tryAutoStart();
      }
      if (tries > 150) { clearInterval(timer); }
    }, 400);
  }

  function tryAutoStart() {
    if (state.autoStarted || state.busy || !state.draft || state.phase === 'run') { return; }
    if (!hasEditor()) { return; }
    if (isStale(state.rec)) {
      dropStored('5분이 지난 초안은 지웠어요');
      hideBanner();
      return;
    }
    state.autoStarted = true;
    run('auto');
  }

  /* ---------- 메시지 ---------- */
  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local' || !changes[STORE_KEY]) { return; }
      var nv = changes[STORE_KEY].newValue;
      if (!nv) { return; }   /* 삭제 알림은 무시 — 진행 중 배너를 지우지 않는다 */
      adoptDraft(nv);
      if (!IS_TOP) { tryAutoStart(); }
    });
  } catch (e) {}

  try {
    chrome.runtime.onMessage.addListener(function (msg) {
      if (!msg || !msg.type) { return; }
      if (msg.type === 'DDOSOMI_RUN_LOG') {
        if (!IS_TOP) { return; }
        state.logs.push({ msg: msg.msg, kind: msg.kind || 'info' });
        while (state.logs.length > MAX_LOG) { state.logs.shift(); }
        renderLog();
        return;
      }
      if (msg.type === 'DDOSOMI_RUN_STATE') {
        if (!IS_TOP) { return; }
        state.phase = msg.phase || 'run';
        state.phaseText = msg.text || '';
        renderPhase();
        return;
      }
      if (msg.type === 'DDOSOMI_RUN_STOP') {
        if (state.busy) { state.stop = true; log('중지 요청 — 안전한 곳에서 멈출게요', 'warn'); }
        return;
      }
      if (msg.type === 'DDOSOMI_RUN_RETRY') {
        if (!IS_TOP && hasEditor() && !state.busy) {
          state.stop = false;
          state.autoStarted = true;
          run('retry');
        }
        return;
      }
      if (msg.type === 'DDOSOMI_DROP_DRAFT') {
        closeBanner();
      }
    });
  } catch (e) {}

  sweepStale();
  loadDraft();
  startPolling();

  window.addEventListener('load', function () {
    if (state.draft && !IS_TOP) { tryAutoStart(); }
    if (state.draft && IS_TOP) { showBanner(); }
  });
})();
