/* 또소미 네이버 자동 임시저장 — 에디터에 넣을 HTML 조각 만들기 (순수 함수 모음) */
(function (root) {
  'use strict';

  var FONT = "'NanumBarunGothic','나눔바른고딕','나눔고딕','Malgun Gothic','Apple SD Gothic Neo',sans-serif";
  var HL = '#ffd300';
  var HEADER_BG = '#f5f6f8';
  var LINE = '#dfe5ec';

  function T(s) { return String(s == null ? '' : s); }
  function trim(s) { return T(s).replace(/^\s+|\s+$/g, ''); }

  function esc(s) {
    return T(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ==노란 형광펜== → 배경 #ffd300 + 볼드, **볼드** → 볼드 */
  function inline(s) {
    var out = esc(s);
    out = out.replace(/==([^=]+?)==/g, '<span style="background-color:' + HL + ';font-weight:bold;">$1</span>');
    out = out.replace(/\*\*(.+?)\*\*/g, '<span style="font-weight:bold;">$1</span>');
    out = out.replace(/\n/g, '<br />');
    return out;
  }

  function paragraph(text) {
    return '<p style="text-align:center;font-family:' + FONT + ';font-size:15pt;line-height:1.8;margin:0 0 12px;">' +
      inline(trim(text)) + '</p>';
  }

  /* [인용구] 소제목 — 에디터 인용구 모양과 비슷하게 왼쪽 선 + 볼드 */
  function quote(text) {
    return '<p style="text-align:center;font-family:' + FONT + ';font-size:18pt;font-weight:bold;line-height:1.5;' +
      'border-left:3px solid #c8d2de;background-color:#f7f9fb;padding:8px 12px;margin:22px 0 12px;">' +
      inline(trim(text)) + '</p>';
  }

  function imageHtml(dataUrl, alt) {
    return '<p style="text-align:center;margin:0 0 14px;"><img src="' + esc(dataUrl) + '" alt="' + esc(alt || '') +
      '" style="max-width:100%;height:auto;" /></p>';
  }

  /* 요약표: 제목 16pt · 헤더 15pt(#f5f6f8) · 셀 13pt 가운데 정렬 */
  function table(t) {
    t = t || {};
    var header = t.header || [];
    var rows = t.rows || [];
    if (!header.length) { return ''; }
    var html = '';
    if (trim(t.title)) {
      html += '<p style="text-align:center;font-family:' + FONT + ';font-size:16pt;font-weight:bold;line-height:1.4;margin:22px 0 9px;">' +
        inline(trim(t.title)) + '</p>';
    }
    html += '<table style="border-collapse:collapse;width:100%;font-family:' + FONT + ';">';
    html += '<tbody><tr>';
    for (var h = 0; h < header.length; h++) {
      html += '<td style="border:1px solid ' + LINE + ';background-color:' + HEADER_BG + ';font-size:15pt;font-weight:bold;text-align:center;vertical-align:middle;padding:8px 10px;">' +
        inline(header[h]) + '</td>';
    }
    html += '</tr>';
    for (var r = 0; r < rows.length; r++) {
      html += '<tr>';
      for (var c = 0; c < rows[r].length; c++) {
        html += '<td style="border:1px solid ' + LINE + ';font-size:13pt;font-weight:normal;text-align:center;vertical-align:middle;padding:8px 10px;">' +
          inline(rows[r][c]) + '</td>';
      }
      html += '</tr>';
    }
    html += '</tbody></table>';
    return html;
  }

  function tags(list) {
    if (!list || !list.length) { return ''; }
    return '<p style="text-align:center;font-family:' + FONT + ';font-size:13pt;margin:22px 0 0;">' +
      esc(list.join(' ')) + '</p>';
  }

  function paragraphsOf(text) {
    var out = [];
    var lines = T(text).replace(/\r\n/g, '\n').split('\n');
    for (var i = 0; i < lines.length; i++) {
      if (trim(lines[i])) { out.push(trim(lines[i])); }
    }
    return out;
  }

  /* 에디터에는 블록 단위로 하나씩 넣는다 (한 번에 넣으면 에디터가 다시 그리며 날리는 경우가 있음) */
  function buildBlocks(d) {
    d = d || {};
    var out = [];
    var intro = d.intro || [];
    var i;
    for (i = 0; i < intro.length; i++) {
      if (trim(intro[i])) { out.push({ type: 'html', html: paragraph(intro[i]) }); }
    }
    var sections = d.sections || [];
    for (i = 0; i < sections.length; i++) {
      var sec = sections[i] || {};
      if (trim(sec.quote)) { out.push({ type: 'html', html: quote(sec.quote) }); }
      if (sec.photo) { out.push({ type: 'image', dataUrl: sec.photo, alt: trim(sec.quote) }); }
      var body = paragraphsOf(sec.body);
      for (var b = 0; b < body.length; b++) {
        out.push({ type: 'html', html: paragraph(body[b]) });
      }
    }
    /* 본문 구조를 못 읽었을 때: 원문 문단을 그대로 넣는다 */
    if (!sections.length && trim(d.bodyText)) {
      var raw = paragraphsOf(d.bodyText);
      for (i = 0; i < raw.length; i++) {
        out.push({ type: 'html', html: paragraph(raw[i]) });
      }
    }
    if (d.table && d.table.header && d.table.header.length) {
      var t = table(d.table);
      if (t) { out.push({ type: 'html', html: t }); }
    }
    var closing = d.closing || [];
    for (i = 0; i < closing.length; i++) {
      if (trim(closing[i])) { out.push({ type: 'html', html: paragraph(closing[i]) }); }
    }
    if (d.hashtags && d.hashtags.length) {
      out.push({ type: 'html', html: tags(d.hashtags) });
    }
    return out;
  }

  function buildHtml(d) {
    var blocks = buildBlocks(d);
    var out = '';
    for (var i = 0; i < blocks.length; i++) {
      if (blocks[i].type === 'html') { out += blocks[i].html; }
      else if (blocks[i].type === 'image') { out += imageHtml(blocks[i].dataUrl, blocks[i].alt); }
    }
    return out;
  }

  function buildPlain(d) {
    d = d || {};
    var lines = [];
    if (trim(d.title)) { lines.push(trim(d.title)); }
    var intro = d.intro || [];
    for (var i = 0; i < intro.length; i++) { if (trim(intro[i])) { lines.push(trim(intro[i])); } }
    var sections = d.sections || [];
    for (var s = 0; s < sections.length; s++) {
      lines.push('');
      if (trim(sections[s].quote)) { lines.push(trim(sections[s].quote)); }
      var body = paragraphsOf(sections[s].body);
      for (var b = 0; b < body.length; b++) { lines.push(body[b].replace(/==/g, '')); }
    }
    if (d.table && d.table.header && d.table.header.length) {
      lines.push('');
      if (trim(d.table.title)) { lines.push(trim(d.table.title)); }
      lines.push(d.table.header.join(' | '));
      for (var r = 0; r < (d.table.rows || []).length; r++) { lines.push(d.table.rows[r].join(' | ')); }
    }
    var closing = d.closing || [];
    for (var c = 0; c < closing.length; c++) { if (trim(closing[c])) { lines.push(trim(closing[c])); } }
    if (d.hashtags && d.hashtags.length) { lines.push(d.hashtags.join(' ')); }
    return lines.join('\n');
  }

  root.TtosomiDraft = {
    FONT: FONT,
    HIGHLIGHT: HL,
    esc: esc,
    inline: inline,
    paragraph: paragraph,
    quote: quote,
    table: table,
    tags: tags,
    buildBlocks: buildBlocks,
    buildHtml: buildHtml,
    buildPlain: buildPlain
  };
})(typeof window !== 'undefined' ? window : this);
